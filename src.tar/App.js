import './App.css'

import LoginPage from './components/LoginPage'

const App = () => <LoginPage />

export default App
